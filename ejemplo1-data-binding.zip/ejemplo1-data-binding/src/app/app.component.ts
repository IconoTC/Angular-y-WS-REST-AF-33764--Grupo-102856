import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  nombre: string = "Anabel";
  apellido: string = "Vegas";

  deshabilitado: boolean = true;

  texto: string = "";

  constructor(){
    // Crear un temporizador que cuando transcurran 3 segundos
    // habilite el boton
    //setTimeout(function, msegundos);
    setTimeout( () => {
      this.deshabilitado = false;
    }, 3000);
  }

  saludar(): void{
    alert("Bienvenidos al curso de Angular");
  }

}

import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 0;

  @HostBinding('style.font-size') // Funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity')
  opacidad: number = 0.1;

  constructor() { }

  @HostListener('click')
  procesarClicks(): void{
    this.numeroClicks++;
    this.size = (15 + this.numeroClicks + "px");
    this.opacidad += 0.1;
  }

}

import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  amigos: any[] = [];
  contacto: any;
  id: number = 0;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    id: new FormControl(0, [Validators.required, Validators.min(1)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.amigos = agendaService.getAll();
  }

  editar(): void{
    this.mostrar = true;
    this.amigoForm.setValue(this.contacto);
  }

  modificar(): void{
    this.agendaService.modificarAmigo(this.amigoForm.value);
    this.mostrar = false;  // ocultar el formulario
    this.contacto = null; // ocultar el contacto encontrado
    this.id = 0;  // Limpiar el formulario
    this.amigoForm.reset();
  }

  eliminar(): void{
    this.agendaService.eliminarAmigo(this.id);
    this.id = 0;  // Limpiar el formulario
    this.contacto = null;  // ocultar el contacto encontrado
  }

  buscar():void{
    this.contacto = this.agendaService.buscarAmigo(this.id);
  }

  alta(): void{
    console.log(this.amigoForm.value);
    this.agendaService.nuevoAmigo(this.amigoForm.value);
  }
}

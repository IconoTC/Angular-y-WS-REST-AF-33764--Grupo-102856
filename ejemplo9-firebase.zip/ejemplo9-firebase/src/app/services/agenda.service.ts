import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  getAll(){

  }

  nuevoAmigo(nuevo: any){
    
  }

  buscarAmigo(id: string){
   
  }

  eliminarAmigo(id: string){
    
  }

  modificarAmigo(id: string, amigo: any){
    
  }
}

import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  idioma: string = 'es';
  logado: boolean = false;

  constructor(private translateService: TranslateService, private loginService: LoginService) {
    // Configuramos el idioma por defecto
    translateService.setDefaultLang(this.idioma);

    loginService.comprobarLogado().subscribe(datos => {
      if (datos == null){
        this.logado = false;
      } else {
        this.logado = true;
      }
    });
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;
    // Cambiamos el idioma de TODA LA APLICACION, no solo de este componente
    this.translateService.use(nuevoIdioma);
  }

  logout(){
    this.loginService.logout()
      .then(() => {
        this.logado = false;
        alert("Session cerrada");
      })
      .catch(error => {
            console.log(error);
      })
  }

  ngOnInit(): void {
  }

}

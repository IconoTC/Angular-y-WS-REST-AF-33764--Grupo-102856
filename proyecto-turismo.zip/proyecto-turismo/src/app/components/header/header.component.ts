import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  idioma: string = 'es';

  constructor(private translateService: TranslateService) {
    // Configuramos el idioma por defecto
    translateService.setDefaultLang(this.idioma);
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;
    // Cambiamos el idioma de TODA LA APLICACION, no solo de este componente
    this.translateService.use(nuevoIdioma);
  }

  ngOnInit(): void {
  }

}

import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Pipe({
  name: 'estado',
  pure: false
})
export class EstadoPipe implements PipeTransform {

  constructor(private translateService: TranslateService){}

  transform(value: unknown, ...args: unknown[]): unknown {
    if (value){
      return this.translateService.instant("pipe.abierto");
    } else {
      return this.translateService.instant("pipe.cerrado");
    }
  }

}

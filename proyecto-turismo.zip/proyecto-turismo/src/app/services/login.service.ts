import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private angularFireAuth: AngularFireAuth) { }

  login(emil: string, pw: string){
    return this.angularFireAuth.signInWithEmailAndPassword(emil, pw);
  }

  registro(emil: string, pw: string){
    return this.angularFireAuth.createUserWithEmailAndPassword(emil, pw);
  }

  logout(){
    return this.angularFireAuth.signOut();
  }

  comprobarLogado(){
    return this.angularFireAuth.authState;
  }
}

export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBvOBYdiV7TkoP9Q_I9IqUMfoauREpDAvI",
    authDomain: "angular-indra-anabel-9-10-2026.firebaseapp.com",
    projectId: "angular-indra-anabel-9-10-2026",
    storageBucket: "angular-indra-anabel-9-10-2026.firebasestorage.app",
    messagingSenderId: "517907130387",
    appId: "1:517907130387:web:0dbd3f7045904a26b677e6"
  }
};

// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBvOBYdiV7TkoP9Q_I9IqUMfoauREpDAvI",
    authDomain: "angular-indra-anabel-9-10-2026.firebaseapp.com",
    projectId: "angular-indra-anabel-9-10-2026",
    storageBucket: "angular-indra-anabel-9-10-2026.firebasestorage.app",
    messagingSenderId: "517907130387",
    appId: "1:517907130387:web:0dbd3f7045904a26b677e6"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
